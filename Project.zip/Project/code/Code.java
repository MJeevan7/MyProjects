package code;

import java.io.*;
import java.lang.Math;
import java.nio.*;
import javax.swing.*;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.util.*;
import com.jogamp.common.nio.Buffers;
import org.joml.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Code extends JFrame implements GLEventListener, KeyListener
{	private GLCanvas myCanvas;
	private int renderingProgram1, renderingProgram2, renderingProgramCubeMap;
	private int vao[] = new int[1];
	private int vbo[] = new int[16];
	private float cameraX, cameraY, cameraZ;
	private float objLocX, objLocY, objLocZ;
    
    // allocate variables for display() function
	private FloatBuffer vals = Buffers.newDirectFloatBuffer(16);
	private Matrix4f pMat = new Matrix4f();  // perspective matrix
	private Matrix4f vMat = new Matrix4f();  // view matrix
	private Matrix4f mMat = new Matrix4f();  // model matrix
	private Matrix4f invTrMat = new Matrix4f(); // inverse-transpose
	private int mLoc, vLoc, pLoc, nLoc, sLoc, i = 0;
	private int globalAmbLoc, ambLoc, diffLoc, specLoc, posLoc, mambLoc, mdiffLoc, mspecLoc, mshiLoc;
	private float aspect;
	private Vector3f currentLightPos = new Vector3f();
	private float[] lightPos = new float[3];
	private Vector3f origin = new Vector3f(0.0f, 0.0f, 0.0f);
	private Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
    private Vector3f initialLightLoc = new Vector3f(-0.5f, 1.0f, 0.5f);
	private float amt = 0.0f;
    private float inc = 0.05f;
	private double prevTime;
	private double elapsedTime;
    private float rX, rZ;
    
	private double tf, startTime, elapseTime, rotX, rotY, kRotY, rotZ, kX, kY, kZ, t, rotL;
	private double incR = 1.0;
	private double zIncR = 0.1;
	private double dX = 0.0, drX = 0.0, dX2 = 0.0;
	private double dZ = 0.0, drZ = 0.0, dZ2 = 0.0;
    private boolean linesOnly = false;
    private boolean changeBoard = true;
    private boolean moving = false;
    private boolean moveStart = false; 
    private boolean forwardMove = true;	
    private boolean rotateLight = false, moveRook = false, movingRook = false, knight1Start = false, a = false, moveRook2 = false, movingRook2 = false, knight2Start = false, movingknight2 = false, moveRook3 = false, movingRook3 = false, knight1End = false, capturedKing = false, reset =false;	
	private int knightTexture, numKnightVertices, boardTexture, boardTexture2, numBoardVertices, skyboxTexture, woodTexture, woodWhiteTexture, numRookVertices, numKingVertices, numPawnVertices;
	private ImportedModel knightModel, boardModel, rookModel, kingModel, pawnModel;
    
    // white light properties
	float[] globalAmbient = new float[] { 0.7f, 0.7f, 0.7f, 1.0f };
	float[] lightAmbient = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	float[] lightDiffuse = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
	float[] lightSpecular = new float[] { 1.0f, 1.0f, 1.0f, 1.0f };
		
    
    private float[] matAmb, matDif, matSpe;
	private float matShi;
    
    // shadow stuff
	private int scSizeX, scSizeY;
	private int [] shadowTex = new int[1];
	private int [] shadowBuffer = new int[1];
	private Matrix4f lightVmat = new Matrix4f();
	private Matrix4f lightPmat = new Matrix4f();
	private Matrix4f shadowMVP1 = new Matrix4f();
	private Matrix4f shadowMVP2 = new Matrix4f();
	private Matrix4f b = new Matrix4f();

	public Code()
	{	setTitle("Project");
		setSize(600, 600);
        GLProfile glp = GLProfile.getMaxProgrammableCore(true);
        GLCapabilities caps = new GLCapabilities(glp);
        myCanvas = new GLCanvas(caps);
		myCanvas.addGLEventListener(this);
        myCanvas.addKeyListener(this);
        myCanvas.setFocusable(true);
		this.add(myCanvas);
		this.setVisible(true);
		Animator animator = new Animator(myCanvas);
		animator.start();
	}

	public void display(GLAutoDrawable drawable)
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
		gl.glClear(GL_COLOR_BUFFER_BIT);
		gl.glClear(GL_DEPTH_BUFFER_BIT);

		// draw cube map
		
		gl.glUseProgram(renderingProgramCubeMap);
        
		vLoc = gl.glGetUniformLocation(renderingProgramCubeMap, "v_matrix");
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));

		pLoc = gl.glGetUniformLocation(renderingProgramCubeMap, "p_matrix");
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
				
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_CUBE_MAP, skyboxTexture);

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);	     // cube is CW, but we are viewing the inside
		gl.glDisable(GL_DEPTH_TEST);
		gl.glDrawArrays(GL_TRIANGLES, 0, 36);
		gl.glEnable(GL_DEPTH_TEST);
        
        currentLightPos.set(initialLightLoc);
                
        if(rotateLight){
            elapseTime = System.currentTimeMillis() - prevTime;
     		prevTime = System.currentTimeMillis();
     		amt += elapseTime * inc;
    
            rotateLight = false;
        }
        
        currentLightPos.rotateAxis((float)Math.toRadians(amt), 0.0f, 1.0f, 0.0f);
	
		lightVmat.identity().setLookAt(currentLightPos, origin, up);	// vector from light to origin
		lightPmat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);

		gl.glBindFramebuffer(GL_FRAMEBUFFER, shadowBuffer[0]);
		gl.glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, shadowTex[0], 0);
	
		gl.glDrawBuffer(GL_NONE);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glEnable(GL_POLYGON_OFFSET_FILL);	//  for reducing
		gl.glPolygonOffset(2.0f, 4.0f);		//  shadow artifacts
	    
        passOne();
		
		gl.glDisable(GL_POLYGON_OFFSET_FILL);	// artifact reduction, continued
		
		gl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, shadowTex[0]);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "shadowTex"), 0);
	
		gl.glDrawBuffer(GL_FRONT);
		
		passTwo();
	}
    
    public void passOne()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
	
		gl.glUseProgram(renderingProgram1);
        
        // draw the rook
        mMat.identity();  	
        mMat.translate(objLocX - (float)drX, objLocY, objLocZ - (float)drZ);
        mMat.translate(0.37f, 0.0f, 0.40f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f); 
     
        if(moveRook){
            startTime = System.currentTimeMillis(); //start time
            rZ = 0.00f;
            moveRook = false;
            movingRook = true;
        }
        if(movingRook){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rZ < 1.8f){
                rZ = (float)(0.4f*t);
                mMat.translate(0.0f, 0.0f, (float)rZ);
            }
            else {
                drZ = 0.45;
                knight1Start = true;
                movingRook = false;
            }
         } 
         
        if(moveRook2){
            startTime = System.currentTimeMillis(); //start time
            rX = 0.00f;
            moveRook2 = false;
            movingRook2 = true;
        }
        if(movingRook2){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rX < 0.75f){
                rX = (float)(0.4f*t);
                mMat.translate((float)rX, 0.0f, 0.0f);
            }
            else {
                drX = 0.1875;
                knight2Start = true;
                movingRook2 = false;
            }
         }                        
         
        if(moveRook3){
            startTime = System.currentTimeMillis(); //start time
            rX = 0.00f;
            moveRook3 = false;
            movingRook3 = true;
        }
        if(movingRook3){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rX < 2.275f){
                rX = (float)(0.4f*t);
                mMat.translate((float)rX, 0.0f, 0.0f);
            }
            else {
                drX = 0.76;
                capturedKing = true;
                movingRook3 = false;
            }
         }          
                     	
		shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, rookModel.getNumVertices());

		// draw the knight        
        mMat.identity(); 
         
        if (knight1Start){
            startTime = System.currentTimeMillis(); //start time
            kX = kY = kZ = 0.00f; //0.0001 to avoid some potential bugs
            knight1Start = false; //you only need it to “trigger” moving
            moving = true;
        }
        if(moving){
		    elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0; 
            
            if(forwardMove){
                kX = (float)(-0.16*t);
                kY = (float)(-0.3*t*t + 0.42*t);
                kZ = (float)(0.075*t); 
            }
            
            if (kY < 0.0f) {
                kY = 0.0f;
                moving = false;
                moveRook2 = true;
                dX = kX;    
                dZ = kZ; 
            } 
            
            mMat.translate((float)kX, (float)kY, (float)kZ);     
        }
        
            if(knight1End){
                mMat.rotateX(8.0f);
            } 
        
 		mMat.translate(objLocX + (float)dX, objLocY, objLocZ + (float)dZ);
        mMat.translate(0.40f, 0.0f, -0.17f);     
		mMat.rotateXYZ(0, 59.6f + (float)kRotY, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);        
         
        shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);    
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals)); 

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
        	
		//gl.glClear(GL_DEPTH_BUFFER_BIT);
 		gl.glEnable(GL_CULL_FACE);
 		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
        
		gl.glDrawArrays(GL_TRIANGLES, 0, knightModel.getNumVertices());
        
        // draw the red knight
		mMat.identity(); 
        
        if (knight2Start){
            startTime = System.currentTimeMillis(); //start time
            kX = kY = kZ = 0.00f; //0.0001 to avoid some potential bugs
            knight2Start = false; //you only need it to “trigger” moving
            movingknight2 = true;
        }
        if(movingknight2){
		    elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0; 
            
            kX = (float)(-0.088*t);
            kY = (float)(-0.3*t*t + 0.42*t);
            kZ = (float)(-0.166*t); 

            if (kY < 0.0f) {
                kY = 0.0f;
                movingknight2 = false;
                moveRook3 = true;
                dX2 = kX;    
                dZ2 = kZ;                   
            } 
            
            mMat.translate((float)kX, (float)kY, (float)kZ);
            knight1End = true;     
        } 
        
		mMat.translate(objLocX + (float)dX2, objLocY, objLocZ + (float)dZ2);
        mMat.translate(0.18f, 0.0f, 0.40f);     
		mMat.rotateXYZ(0, 59.6f + (float)kRotY, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);       
                           	
		shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		//gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, knightModel.getNumVertices());

        // draw the white king
		mMat.identity();  
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.18f, 0.0f, 0.18f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f);    
                	
		shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		//gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, kingModel.getNumVertices());
        
        // draw the red king
		mMat.identity(); 
        if(capturedKing){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
                 mMat.rotateXYZ(0.0f, 0.0f, ((float)Math.cos(t)*0.03f)-0.03f);
         } 
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.38f, 0.0f, 0.05f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f);  
                	
		shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		//gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, kingModel.getNumVertices());

        // draw the pawn
		mMat.identity();  
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.28f, 0.0f, 0.05f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);    
                	
		shadowMVP1.identity();
		shadowMVP1.mul(lightPmat);
		shadowMVP1.mul(lightVmat);
		shadowMVP1.mul(mMat);
        
        sLoc = gl.glGetUniformLocation(renderingProgram1, "shadowMVP");
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP1.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		//gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, pawnModel.getNumVertices());

	}

    public void passTwo()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
	
		gl.glUseProgram(renderingProgram2);
		
		mLoc = gl.glGetUniformLocation(renderingProgram2, "m_matrix");
		vLoc = gl.glGetUniformLocation(renderingProgram2, "v_matrix");
		pLoc = gl.glGetUniformLocation(renderingProgram2, "p_matrix");
		nLoc = gl.glGetUniformLocation(renderingProgram2, "norm_matrix");
		sLoc = gl.glGetUniformLocation(renderingProgram2, "shadowMVP");
        
        vMat.identity().setTranslation(-cameraX,-cameraY,-cameraZ-(float)rotZ);
        vMat.rotateX((float) Math.toRadians(rotX + 10.0)); 
        vMat.rotateY((float) Math.toRadians(rotY));
         
        // draw the rook       
        installLights(renderingProgram2);
               
		mMat.identity();  	
        mMat.translate(objLocX - (float)drX, objLocY, objLocZ - (float)drZ);
        mMat.translate(0.37f, 0.0f, 0.40f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f); 
        
        if(moveRook){
            //reset = false;
            System.out.println(reset);
        }
     
        if(moveRook){
            //reset=false;
            startTime = System.currentTimeMillis(); //start time
            rZ = 0.00f;
            //rY = 0.00f;
            rX = 0.00f;
            moveRook = false;
            movingRook = true;
            //reset=false;
        }
        if(movingRook){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rZ < 1.8f){
                rZ = (float)(0.5f*t);
                mMat.translate(0.0f, 0.0f, (float)rZ);
            }
            else {
                drZ = 0.45;
                knight1Start = true;
                movingRook = false;
            }
         }
         
         if(reset){
            drX=0.0f;
            drZ=0.0f;
            //reset=false;
         }
         
        if(moveRook2){
            startTime = System.currentTimeMillis(); //start time
            rX = 0.00f;
            rZ = 0.00f;
            //rY = 0.00f;
            moveRook2 = false;
            movingRook2 = true;
            
        }
        if(movingRook2){
            //knight1End = true;
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rX < 0.75f){
                rX = (float)(0.5f*t);
                mMat.translate((float)rX, 0.0f, 0.0f);
            }
            else {
                drX = 0.1875;
                //knight1End = true;
                knight2Start = true;
                // knight1End = true;
                movingRook2 = false;
            }
         }                        
         
        if(moveRook3){
            startTime = System.currentTimeMillis(); //start time
            rX = 0.00f;
            rZ = 0.00f;
            //rY = 0.00f;
            moveRook3 = false;
            movingRook3 = true;
        }
        if(movingRook3){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
            
            if(rX < 2.275f){
                rX = (float)(0.5f*t);
                mMat.translate((float)rX, 0.0f, 0.0f);
            }
            else {
                drX = 0.76;
                capturedKing = true;
                movingRook3 = false;
            }
         }          
         		   
		mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);   
                	
		shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodWhiteTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }
        
		gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, rookModel.getNumVertices());

        
        // draw the knight        
		mMat.identity(); 
        
        if (knight1Start){
            startTime = System.currentTimeMillis(); //start time
            kX = kY = kZ = 0.00f; //0.0001 to avoid some potential bugs
            knight1Start = false; //you only need it to “trigger” moving
            moving = true;
        }
        if(moving){
		    elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0; 
            
            if(forwardMove){
                kX = (float)(-0.16*t);
                kY = (float)(-0.3*t*t + 0.42*t);
                kZ = (float)(0.075*t); 
            }
            
            if (kY < 0.0f) {
                kY = 0.0f;
                moving = false;
                moveRook2 = true;
                dX = kX;    
                dZ = kZ; 
            } 
            
            mMat.translate((float)kX, (float)kY, (float)kZ);     
        }
        
        if(reset){
        dX=0.0f;
        dZ=0.0f;
        mMat.rotateX(-8.0f);
        //reset=false;
        }
        
        if(knight1End){
            mMat.rotateX(8.0f);
        } 
        
		mMat.translate(objLocX + (float)dX, objLocY, objLocZ + (float)dZ);
        mMat.translate(0.40f, 0.0f, -0.17f);     
		mMat.rotateXYZ(0, 59.6f + (float)kRotY, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);       
        
        mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);     
                	
		shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, knightModel.getNumVertices());
        
        // draw the red knight
		mMat.identity(); 
        
        if (knight2Start){
            startTime = System.currentTimeMillis(); //start time
            kX = kY = kZ = 0.00f; //0.0001 to avoid some potential bugs
            knight2Start = false; //you only need it to “trigger” moving
            movingknight2 = true;
        }
        if(movingknight2){
		    elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0; 
            
            kX = (float)(-0.088*t);
            kY = (float)(-0.3*t*t + 0.42*t);
            kZ = (float)(-0.166*t); 

            if (kY < 0.0f) {
                kY = 0.0f;
                movingknight2 = false;
                moveRook3 = true;
                dX2 = kX;    
                dZ2 = kZ;                   
            } 
            
            mMat.translate((float)kX, (float)kY, (float)kZ);
            knight1End = true;     
        }
        
        if(reset){
        dX2=0.0f;
        dZ2=0.0f;
        reset=false;
        }
        
		mMat.translate(objLocX + (float)dX2, objLocY, objLocZ + (float)dZ2);
        mMat.translate(0.18f, 0.0f, 0.40f);     
		mMat.rotateXYZ(0, 59.6f + (float)kRotY, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);       
        
        shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, knightModel.getNumVertices());

        // draw the white king
		mMat.identity();  
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.18f, 0.0f, 0.18f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f);       
                 		   
		mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);   
                	
		shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodWhiteTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, kingModel.getNumVertices());
        
        // draw the red king
		mMat.identity();  
        
        if(capturedKing){
            elapsedTime = System.currentTimeMillis() - startTime;
		    t = elapsedTime/1000.0;
                 mMat.rotateXYZ(0.0f, 0.0f, ((float)Math.cos(t)*0.03f)-0.03f);
         }
         
         if(reset){
         capturedKing=false;
         //moveRook=true;
         reset=false;
         }
        
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.38f, 0.0f, 0.05f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.25f, 0.25f, 0.25f);       
                 		   
		mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);   
                	
		shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, kingModel.getNumVertices());

        // draw the pawn
		mMat.identity();  
		mMat.translate(objLocX, objLocY, objLocZ);
        mMat.translate(-0.28f, 0.0f, 0.05f);     
		mMat.rotateXYZ(0, 59.6f, 0);  
        mMat.scale(0.012f, 0.012f, 0.012f);                        
		   
		mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);   
                	
		shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[14]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[15]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, woodWhiteTexture);
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        
        if (linesOnly) {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
            } else {
            gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
        }

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, pawnModel.getNumVertices());

		// draw the board
        mMat.identity();   
                    
        mMat.invert(invTrMat);
		invTrMat.transpose(invTrMat);    
        
        shadowMVP2.identity();
		shadowMVP2.mul(b);
		shadowMVP2.mul(lightPmat);
		shadowMVP2.mul(lightVmat);
		shadowMVP2.mul(mMat);
        
		gl.glUniformMatrix4fv(mLoc, 1, false, mMat.get(vals));
		gl.glUniformMatrix4fv(vLoc, 1, false, vMat.get(vals));
		gl.glUniformMatrix4fv(pLoc, 1, false, pMat.get(vals));
		gl.glUniformMatrix4fv(nLoc, 1, false, invTrMat.get(vals));
		gl.glUniformMatrix4fv(sLoc, 1, false, shadowMVP2.get(vals));

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(1, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
        
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		gl.glVertexAttribPointer(2, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);

		gl.glActiveTexture(GL_TEXTURE1);
        if (changeBoard) {
		    gl.glBindTexture(GL_TEXTURE_2D, boardTexture);
        } else {
		    gl.glBindTexture(GL_TEXTURE_2D, boardTexture2);
        }
        gl.glUniform1i(gl.glGetUniformLocation(renderingProgram2, "s"), 1);
        gl.glDisable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
		gl.glDrawArrays(GL_TRIANGLES, 0, boardModel.getNumVertices());

	}

	public void init(GLAutoDrawable drawable)
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
        renderingProgram1 = Utils.createShaderProgram("code/vertshader1.glsl", "code/fragshader1.glsl");
		renderingProgram2 = Utils.createShaderProgram("code/vertshader2.glsl", "code/fragshader2.glsl");
		renderingProgramCubeMap = Utils.createShaderProgram("code/vertCShader.glsl", "code/fragCShader.glsl");
        
        prevTime = System.currentTimeMillis();

		aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		pMat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);

		setupVertices();
		setupShadowBuffers();
				
		b.set(
			0.5f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.5f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.5f, 0.0f,
			0.5f, 0.5f, 0.5f, 1.0f);
            
		cameraX = 0.0f; cameraY = 0.0f; cameraZ = 0.65f;
		objLocX = 0.0f; objLocY = 0.0f; objLocZ = 0.0f;

		knightTexture = Utils.loadTexture("gold.jpg");
		boardTexture = Utils.loadTexture("chessBoard.jpg");
		boardTexture2 = Utils.loadTexture("chessBoard2.jpg");
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		skyboxTexture = Utils.loadCubeMap("cubeMap");
		gl.glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
		woodTexture = Utils.loadTexture("Wood.jpg");
		woodWhiteTexture = Utils.loadTexture("WoodWhite.jpg");
	}

	private void setupVertices()
	{	
        GL4 gl = (GL4) GLContext.getCurrentGL();
        
        //--------------------------------------Knight
		knightModel = new ImportedModel("knight.obj");
	
		numKnightVertices = knightModel.getNumVertices();
		Vector3f[] vertices = knightModel.getVertices();
		Vector2f[] texCoords = knightModel.getTexCoords();
		Vector3f[] normals = knightModel.getNormals();
		
		float[] knightpvalues = new float[numKnightVertices*3];
		float[] knighttvalues = new float[numKnightVertices*2];
		float[] knightnvalues = new float[numKnightVertices*3];
		
		for (int i=0; i<numKnightVertices; i++)
		{	knightpvalues[i*3]   = (float) (vertices[i]).x();
			knightpvalues[i*3+1] = (float) (vertices[i]).y();
			knightpvalues[i*3+2] = (float) (vertices[i]).z();
			knighttvalues[i*2]   = (float) (texCoords[i]).x();
			knighttvalues[i*2+1] = (float) (texCoords[i]).y();
			knightnvalues[i*3]   = (float) (normals[i]).x();
			knightnvalues[i*3+1] = (float) (normals[i]).y();
			knightnvalues[i*3+2] = (float) (normals[i]).z();
		}
        
        //--------------------------------------Chess Board
		boardModel = new ImportedModel("board.obj");
	
		numBoardVertices = boardModel.getNumVertices();
		vertices = boardModel.getVertices();
		texCoords = boardModel.getTexCoords();
		normals = boardModel.getNormals();
		
		float[] boardpvalues = new float[numBoardVertices*3];
		float[] boardtvalues = new float[numBoardVertices*2];
		float[] boardnvalues = new float[numBoardVertices*3];
		
		for (int i=0; i<numBoardVertices; i++)
		{	boardpvalues[i*3]   = (float) (vertices[i]).x();
			boardpvalues[i*3+1] = (float) (vertices[i]).y();
			boardpvalues[i*3+2] = (float) (vertices[i]).z();
			boardtvalues[i*2]   = (float) (texCoords[i]).x();
			boardtvalues[i*2+1] = (float) (texCoords[i]).y();
			boardnvalues[i*3]   = (float) (normals[i]).x();
			boardnvalues[i*3+1] = (float) (normals[i]).y();
			boardnvalues[i*3+2] = (float) (normals[i]).z();
		}
        
        // cube
		
		float[] cubeVertexPositions =
		{	-1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f,  1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f, -1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f,  1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f, -1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,
			-1.0f,  1.0f, -1.0f, 1.0f,  1.0f, -1.0f, 1.0f,  1.0f,  1.0f,
			1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f, -1.0f
		};
        
        //--------------------------------------Rook
		rookModel = new ImportedModel("Rook.obj");
	
		numRookVertices = rookModel.getNumVertices();
		vertices = rookModel.getVertices();
		texCoords = rookModel.getTexCoords();
		normals = rookModel.getNormals();
		
		float[] rookpvalues = new float[numRookVertices*3];
		float[] rooktvalues = new float[numRookVertices*2];
		float[] rooknvalues = new float[numRookVertices*3];
		
		for (int i=0; i<numRookVertices; i++)
		{	rookpvalues[i*3]   = (float) (vertices[i]).x();
			rookpvalues[i*3+1] = (float) (vertices[i]).y();
			rookpvalues[i*3+2] = (float) (vertices[i]).z();
			rooktvalues[i*2]   = (float) (texCoords[i]).x();
			rooktvalues[i*2+1] = (float) (texCoords[i]).y();
			rooknvalues[i*3]   = (float) (normals[i]).x();
			rooknvalues[i*3+1] = (float) (normals[i]).y();
			rooknvalues[i*3+2] = (float) (normals[i]).z();
		}

		//--------------------------------------King
		kingModel = new ImportedModel("King.obj");
	
		numKingVertices = kingModel.getNumVertices();
		vertices = kingModel.getVertices();
		texCoords = kingModel.getTexCoords();
		normals = kingModel.getNormals();
		
		float[] kingpvalues = new float[numKingVertices*3];
		float[] kingtvalues = new float[numKingVertices*2];
		float[] kingnvalues = new float[numKingVertices*3];
		
		for (int i=0; i<numKingVertices; i++)
		{	kingpvalues[i*3]   = (float) (vertices[i]).x();
			kingpvalues[i*3+1] = (float) (vertices[i]).y();
			kingpvalues[i*3+2] = (float) (vertices[i]).z();
			kingtvalues[i*2]   = (float) (texCoords[i]).x();
			kingtvalues[i*2+1] = (float) (texCoords[i]).y();
			kingnvalues[i*3]   = (float) (normals[i]).x();
			kingnvalues[i*3+1] = (float) (normals[i]).y();
			kingnvalues[i*3+2] = (float) (normals[i]).z();
		}
        
        //--------------------------------------Pawn
		pawnModel = new ImportedModel("Pawn.obj");
	
		numPawnVertices = pawnModel.getNumVertices();
		vertices = pawnModel.getVertices();
		texCoords = pawnModel.getTexCoords();
		normals = pawnModel.getNormals();
		
		float[] pawnpvalues = new float[numPawnVertices*3];
		float[] pawntvalues = new float[numPawnVertices*2];
		float[] pawnnvalues = new float[numPawnVertices*3];
		
		for (int i=0; i<numPawnVertices; i++)
		{	pawnpvalues[i*3]   = (float) (vertices[i]).x();
			pawnpvalues[i*3+1] = (float) (vertices[i]).y();
			pawnpvalues[i*3+2] = (float) (vertices[i]).z();
			pawntvalues[i*2]   = (float) (texCoords[i]).x();
			pawntvalues[i*2+1] = (float) (texCoords[i]).y();
			pawnnvalues[i*3]   = (float) (normals[i]).x();
			pawnnvalues[i*3+1] = (float) (normals[i]).y();
			pawnnvalues[i*3+2] = (float) (normals[i]).z();
		}
	
		gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);
                
        //--------------------------------------Knight		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		FloatBuffer kniVertBuf = Buffers.newDirectFloatBuffer(knightpvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kniVertBuf.limit()*4, kniVertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		FloatBuffer kniTexBuf = Buffers.newDirectFloatBuffer(knighttvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kniTexBuf.limit()*4, kniTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		FloatBuffer kniNorBuf = Buffers.newDirectFloatBuffer(knightnvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kniNorBuf.limit()*4, kniNorBuf, GL_STATIC_DRAW);
        
        //--------------------------------------Chess Board	
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		FloatBuffer boaVertBuf = Buffers.newDirectFloatBuffer(boardpvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, boaVertBuf.limit()*4, boaVertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		FloatBuffer boaTexBuf = Buffers.newDirectFloatBuffer(boardtvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, boaTexBuf.limit()*4, boaTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		FloatBuffer boaNorBuf = Buffers.newDirectFloatBuffer(boardnvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, boaNorBuf.limit()*4, boaNorBuf, GL_STATIC_DRAW);
        
        //-------------------------------------Cube
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		FloatBuffer cvertBuf = Buffers.newDirectFloatBuffer(cubeVertexPositions);
		gl.glBufferData(GL_ARRAY_BUFFER, cvertBuf.limit()*4, cvertBuf, GL_STATIC_DRAW);
        
        //--------------------------------------Rook		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		FloatBuffer rookVertBuf = Buffers.newDirectFloatBuffer(rookpvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, rookVertBuf.limit()*4, rookVertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		FloatBuffer rookTexBuf = Buffers.newDirectFloatBuffer(rooktvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, rookTexBuf.limit()*4, rookTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		FloatBuffer rookNorBuf = Buffers.newDirectFloatBuffer(rooknvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, rookNorBuf.limit()*4, rookNorBuf, GL_STATIC_DRAW);
        
        //--------------------------------------King		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		FloatBuffer kingVertBuf = Buffers.newDirectFloatBuffer(kingpvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kingVertBuf.limit()*4, kingVertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		FloatBuffer kingTexBuf = Buffers.newDirectFloatBuffer(kingtvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kingTexBuf.limit()*4, kingTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
		FloatBuffer kingNorBuf = Buffers.newDirectFloatBuffer(kingnvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, kingNorBuf.limit()*4, kingNorBuf, GL_STATIC_DRAW);
        
        //--------------------------------------Pawn		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
		FloatBuffer pawnVertBuf = Buffers.newDirectFloatBuffer(pawnpvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, pawnVertBuf.limit()*4, pawnVertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[14]);
		FloatBuffer pawnTexBuf = Buffers.newDirectFloatBuffer(pawntvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, pawnTexBuf.limit()*4, pawnTexBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[15]);
		FloatBuffer pawnNorBuf = Buffers.newDirectFloatBuffer(pawnnvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, pawnNorBuf.limit()*4, pawnNorBuf, GL_STATIC_DRAW);

	}
    
    private void setupShadowBuffers()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
		scSizeX = myCanvas.getWidth();
		scSizeY = myCanvas.getHeight();
	
		gl.glGenFramebuffers(1, shadowBuffer, 0);
	
		gl.glGenTextures(1, shadowTex, 0);
		gl.glBindTexture(GL_TEXTURE_2D, shadowTex[0]);       
		gl.glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32,
		                scSizeX, scSizeY, 0, GL_DEPTH_COMPONENT, GL_FLOAT, null);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
		
		// may reduce shadow border artifacts
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	}

    
    public void keyPressed(KeyEvent e) 
    {
        if (e.getKeyCode()==KeyEvent.VK_RIGHT){
               rotY -= incR;
        }else if (e.getKeyCode()==KeyEvent.VK_LEFT){
               rotY += incR;
        }else if (e.getKeyCode()==KeyEvent.VK_UP){
               rotX -= incR;
        }else if (e.getKeyCode()==KeyEvent.VK_DOWN){
               rotX += incR;
        }else if (e.getKeyCode()==KeyEvent.VK_Z){
               rotZ -= zIncR;
        }else if (e.getKeyCode()==KeyEvent.VK_X){
               rotZ += zIncR;
        }else if (e.getKeyCode()==KeyEvent.VK_Q){
               kRotY -= incR;
        }else if (e.getKeyCode()==KeyEvent.VK_W){
               kRotY += incR;
        }else if (e.getKeyCode() == KeyEvent.VK_L) {
            linesOnly = !linesOnly;
        }else if (e.getKeyCode() == KeyEvent.VK_T) {       
            changeBoard = !changeBoard;
        }else if (e.getKeyCode() == KeyEvent.VK_M) {       
            moveStart = !moveStart;    
        }else if (e.getKeyCode()==KeyEvent.VK_O){
               rotL -= incR;
        }else if (e.getKeyCode()==KeyEvent.VK_P){
               rotL += incR;
        }else if (e.getKeyCode()==KeyEvent.VK_R){
               rotateLight=true;
        }else if (e.getKeyCode()==KeyEvent.VK_S){
               if(i == 0){
                moveRook = true;
                i++;
               }
               else{
                reset = true;
//                 moveRook = true;
                i = 0;
                moveRook = true;
                //reset = false;
               }
        }
        else System.out.println(e.getKeyCode()+" is pressed");
    }
       
    public void keyReleased(KeyEvent e) 
    {
//        System.out.println("keyReleased");
    }
    
    public void keyTyped(KeyEvent e) 
    {
//         System.out.println("keyTyped");
    } 
    
    private void installLights(int renderingProgram)
	{	GL4 gl = (GL4) GLContext.getCurrentGL();

		lightPos[0]=currentLightPos.x(); lightPos[1]=currentLightPos.y(); lightPos[2]=currentLightPos.z();
		
        // set current material values
		matAmb = Utils.silverAmbient();
		matDif = Utils.silverDiffuse();
		matSpe = Utils.silverSpecular();
		matShi = Utils.silverShininess();
        
		// get the locations of the light and material fields in the shader
		globalAmbLoc = gl.glGetUniformLocation(renderingProgram, "globalAmbient");
		ambLoc = gl.glGetUniformLocation(renderingProgram, "light.ambient");
		diffLoc = gl.glGetUniformLocation(renderingProgram, "light.diffuse");
		specLoc = gl.glGetUniformLocation(renderingProgram, "light.specular");
		posLoc = gl.glGetUniformLocation(renderingProgram, "light.position");
		mambLoc = gl.glGetUniformLocation(renderingProgram, "material.ambient");
		mdiffLoc = gl.glGetUniformLocation(renderingProgram, "material.diffuse");
		mspecLoc = gl.glGetUniformLocation(renderingProgram, "material.specular");
		mshiLoc = gl.glGetUniformLocation(renderingProgram, "material.shininess");
        
        //  set the uniform light and material values in the shader
		gl.glProgramUniform4fv(renderingProgram, globalAmbLoc, 1, globalAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram, ambLoc, 1, lightAmbient, 0);
		gl.glProgramUniform4fv(renderingProgram, diffLoc, 1, lightDiffuse, 0);
		gl.glProgramUniform4fv(renderingProgram, specLoc, 1, lightSpecular, 0);
		gl.glProgramUniform3fv(renderingProgram, posLoc, 1, lightPos, 0);
		gl.glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb, 0);
		gl.glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif, 0);
		gl.glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe, 0);
		gl.glProgramUniform1f(renderingProgram, mshiLoc, matShi);
	}

	public static void main(String[] args) { new Code(); }
	public void dispose(GLAutoDrawable drawable) {}
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height)
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
       
        aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		pMat.identity().setPerspective((float) Math.toRadians(60.0f), aspect, 0.1f, 1000.0f);
        
		setupShadowBuffers();
	}
}